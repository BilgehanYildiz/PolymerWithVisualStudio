
if (something) {
  something('hey');
}
